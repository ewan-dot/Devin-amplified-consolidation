# Worktree Plan Research Findings
**Prepared:** 2026-06-21 | **Scope:** Three open technical questions for Amplified Partners' AI-agent code workflow

> **Context reminder:** Amplified uses a proprietary Relay/Vellum auditing+provenance layer. Third-party SaaS auditors (Snyk, CodeRabbit, etc.) are referenced only where they supply independent measurement data — they are **not** recommended as primary gates. All merge authority gating stays with CI + Relay/Vellum checks plus human/pre-validated-plan approval.

---

## Q1: Speed of Gates — Keeping PR/CI from Throttling Velocity Under High AI-PR Volume

### 1.1 Industry CI Latency Targets

The practitioner consensus for p50/p95 CI pipeline duration, drawn from platform engineering benchmarks:

| Tier | p50 target | p95 target | Notes |
|---|---|---|---|
| Elite (DORA) | < 5 min | < 10 min | Correlates with <1 day lead time for changes |
| High-performing | 5–10 min | 10–20 min | [Harness CI metrics guide](https://www.harness.io/blog/top-continuous-integration-metrics-every-platform-engineering-leader-should-track): most developers want builds under 10 min |
| Degraded signal | >10 min median | >20 min p95 | Breaks flow; [Harness](https://www.harness.io/blog/top-continuous-integration-metrics-every-platform-engineering-leader-should-track) notes timeout builds average 19.7 min vs 3.4 min for normal |
| CI queue time | < 2 min | — | Separate from pipeline duration; [DX metrics reference](https://lucaberton.com/blog/developer-experience-metrics-devex/) treats queue time as its own SLO |

[DORA 2024 State of DevOps](https://codeligence.com/research/engineering-metrics/) classifies elite teams as achieving lead time for changes under one day, with the CI pipeline being the dominant internal component. The 2024 survey covered 39,000+ professionals; only 19% hit elite tier.

**Concrete PR review latency targets** (separate from CI):
- PR review first-touch: p50 < 4 h ([DX metrics reference](https://lucaberton.com/blog/developer-experience-metrics-devex/))
- Preview environment availability after PR open: < 5 min ([DX metrics reference](https://lucaberton.com/blog/developer-experience-metrics-devex/))

[SURE] — These targets are broadly stable across multiple independent benchmarking sources and DORA's longitudinal surveys.

---

### 1.2 The AI-PR Review Bottleneck — Documented Empirical Finding

[LinearB's 2026 Software Engineering Benchmarks Report](https://byteiota.com/software-engineering-benchmarks-2026-ai-code-review-gap/), analyzing **8.1 million pull requests from 4,800 teams across 42 countries**, found:

- **AI-generated PRs wait 4.6× longer** before a reviewer picks them up compared to human-authored PRs
- Once review starts, AI PRs are reviewed **2× faster** (reviewers move through them more quickly)
- **Acceptance rate: 32.7%** for AI-generated code vs **84.4%** for manually authored code
- Teams using AI complete 21% more tasks and merge 98% more PRs, but PR review time increased **91%**

The arxiv study [Pinna et al. 2026, MSR'26](https://arxiv.org/abs/2602.08915) — analyzing **7,156 PRs from five agents** (OpenAI Codex, GitHub Copilot, Devin, Cursor, Claude Code) across the AIDev dataset — confirms task type is the dominant acceptance driver: documentation PRs hit **82.1%** acceptance vs **66.1%** for new features (a 16 pp gap that exceeds inter-agent variance). Key agent-specific findings:
- Devin is the **only agent showing consistent positive trend** (+0.77% per week over 32 weeks)
- Claude Code leads in documentation (92.3%) and features (72.6%)
- Cursor leads in fix tasks (80.4%)
- No single agent dominates all task types

**Implication for Amplified:** When Claude Code Max generates many PRs from agent worktrees, a naïve review queue will create a backlog with ~1/3 acceptance rate and 4.6× wait inflation. Gate design must account for this — routing, triage priority, and advisory signals should help humans decide quickly whether a PR merits full review.

[SURE] — LinearB data is the largest dataset on this specific question; arxiv study uses independent AIDev dataset with MSR peer review.

---

### 1.3 What Should Block vs. Run Advisory

The canonical split, consistent across platform engineering practice:

**Blocking (must pass before merge queued):**
- Unit + integration test suite (your own tests, not vendor)
- Linting / type checking (fast, deterministic)
- Contract diff check (breaking change detection on OpenAPI/schema)
- Security baseline checks (secret scanning, known-CVE dependency scan)
- Coverage threshold enforcement (if specified in pre-validated plan)

**Advisory (run in parallel, results posted to PR, do NOT block):**
- Static analysis / code complexity (e.g., SonarQube-style metrics)
- Performance regression tests (too slow and flaky to block)
- Third-party AI review tools (CodeRabbit, Copilot review) — **optional advisory layer only**
- Full E2E / browser tests when not on critical path

[Treblle API governance guide](https://treblle.com/blog/api-governance-best-practices) codifies this as "keep human review focused on API shape, consumer impact, major breaking changes — push everything else into automated checks." The same principle scales to code PRs.

[SURE] — This blocking/advisory split is documented in GitHub Actions guidance, DORA research, and multiple platform engineering references.

---

### 1.4 Merge Queues — How They Recover Velocity at Scale

Without a merge queue, each PR author must keep their branch up to date with `main` and re-run CI after every earlier merge. At high AI-PR volume this becomes serial: with 10-min CI, throughput caps at ~6 merges/hour per branch ([GitHub HN discussion](https://news.ycombinator.com/item?id=36707239)).

**GitHub native merge queue** ([GitHub Docs](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue)):
- Creates a temporary `gh-readonly-queue/{base_branch}/` branch per queued group
- Runs CI against the combined state of queued PRs before merge
- Requires workflows to add `merge_group` as an explicit trigger — the most common setup failure
- Solves safety but is intentionally simple; offers limited parallelism optimization

**Graphite merge queue** ([Graphite docs](https://graphite.com/docs/graphite-merge-queue)):
- Stack-aware: if a feature spans PRs 1→2→3, CI runs concurrently across them, then fast-forwards if all pass
- Parallel CI across independent stacks simultaneously
- Batching: merges groups of stacks at once
- Reported outcomes: [74% faster merge times at Ramp, 7 hours saved per engineer per week at Asana, 21% more code shipped](https://graphite.com/blog/the-first-stack-aware-merge-queue)

**Key decision for Amplified:** With agents each working in an isolated git worktree on their own branch, the branch topology naturally maps to Graphite-style stacks or independent parallel PRs. GitHub native merge queue is sufficient for independent PRs; Graphite adds value if branches are stacked/dependent. Either way, the merge queue must be configured to trigger Relay/Vellum checks as required status — these are the blocking gate, not optional.

[SURE] — Merge queue mechanics are documented. Reported speedup figures are vendor-supplied (treat as directional, not audited benchmarks).

---

### 1.5 Parallelizing Checks at Scale

At high AI-PR volume, the main parallelization levers:

1. **Test sharding** — split test suite across N runners; reduces p50 CI duration proportionally with diminishing returns above ~16 shards. [Pinterest, Uber case studies](https://devblogs.sh/posts/optimizing-our-e2e-pipeline) show 4–5× reductions with affected-test selection (Bazel/Gradle dependency graphs).

2. **Affected-test selection** — run only tests that could be affected by the diff. Risk: coverage gaps. Use for advisory checks, not the sole blocking gate.

3. **Parallelizing across PRs** — use merge queue batching to validate groups of independent PRs against the same combined head in one CI run.

4. **Tiering by PR type** — route documentation PRs, test-only PRs, and config-only PRs through a fast lane with a reduced check set (they can't introduce runtime regressions in unrelated modules).

[STRUCTURED] — Individual techniques are documented; the specific combination tuned for AI-PR-heavy repos is emerging practice, not fully benchmarked.

---

## Q2: Cloud Agent Coding Quality (2026) — What the Evidence Actually Says

### 2.1 The METR RCT — What It Found and What It Didn't

**Original study** ([METR, July 2025](https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/)):
- **Design:** 16 experienced open-source developers, 246 real issues (bug fixes, features, refactors) on their own mature repos (avg 22k+ stars, 1M+ lines). Randomized assignment to AI-allowed vs AI-disallowed.
- **Tooling:** Primarily Cursor Pro with Claude 3.5/3.7 Sonnet (early 2025 frontier).
- **Finding:** Developers using AI took **19% longer** (CI: +2% to +39% slower). Developers estimated they were **20% faster** — a stark perception gap.
- **What this measures:** Total task completion time for experienced contributors on *their own legacy repos*. Not cloud vs local. Not Devin vs Claude Code. Not 2026 tooling.

**Follow-up / redesign** ([METR, Feb 2026](https://metr.org/blog/2026-02-24-uplift-update/)):
- New experiment (Aug 2025 onward, larger pool, latest tools) was **scrapped as unreliable**.
- Reason: many developers refused non-AI tasks ("I don't work this way anymore"), biasing the comparison.
- Raw data from returning original 10 developers: estimated **18% speedup** — a sign-flip — but CI was -38% to +9%, effectively noise.
- Among 47 new participants: 4% speedup, statistically indistinguishable from zero.
- METR's conclusion: "we believe developers are likely more sped up from AI tools now — in early 2026 — compared to our estimates from early 2025. However, our data is only very weak evidence for the size of this increase."

[SURE] — Primary sources are METR.org. The 19%-slower finding is real and well-documented. The Feb 2026 update explicitly withdrew the follow-up headline number.

**What the 19% finding does NOT say:** It does not address cloud vs local agent execution, Amplified's worktree isolation pattern, or autonomous agent modes (the study used Cursor in interactive mode, not background/autonomous agents).

---

### 2.2 METR's August 2025 Quality Update — The "Not Mergeable" Finding

Separate from the productivity RCT, [METR's August 2025 research update](https://metr.org/blog/2025-08-12-research-update-towards-reconciling-slowdown-with-time-horizons/) manually reviewed AI-generated PRs from the same 18 tasks:

- Claude 3.7 Sonnet achieved **38% (±19%) success rate** on maintainer-written tests — reasonable functional accuracy
- On manual PR review: **none of the PRs were mergeable as-is**
- Failure taxonomy: missing/incorrect core functionality, poor test coverage, formatting/linting violations, missing/incorrect documentation, other quality issues (verbosity, brittleness)
- METR note: "even when agents pass on all human-written test cases, implementations would take 20–30 minutes on average to get to mergeable state — about a third of the total human time for the task"

This is the single most important finding for Amplified's Relay/Vellum verification layer design: **functional correctness on CI tests is a necessary but not sufficient signal for merge readiness.** A PR that passes all blocking CI checks may still require 20–30 min of manual polishing.

[SURE] — Primary source is METR.org blog post with explicit methodology. Directly contradicts "AI PRs are merge-ready if tests pass."

---

### 2.3 Cloud Agent vs Local — The Correct Question

The question "does cloud write better code than local?" conflates two independent variables:

**Variable A: Model size/quality** (larger cloud models vs smaller local models)
- Cloud frontier models (Claude Opus, GPT-5) consistently outperform small local models on complex multi-file reasoning, bug detection, and architectural tasks — [benchmark comparison](https://www.kunalganglani.com/blog/local-llm-vs-claude-coding-benchmark): 60%+ advantage on multi-file context tasks
- For routine tasks (boilerplate, tests, single-file refactors), local 14B models reach 85–90% of cloud quality at zero marginal cost ([fp8.co comparison](https://fp8.co/articles/Local-AI-Coding-Agents-Small-Models-vs-Cloud-Comparison))
- This is a **model capability question**, not a cloud execution question

**Variable B: Execution environment** (cloud sandbox vs local worktree)
- Cloud sandboxes offer: network isolation, no local state contamination, auditable environment, no port/process conflicts with developer's main session
- Worktrees on local/server offer: the same isolation benefits at the filesystem/branch level, plus shared compute, faster iteration, no round-trip latency
- [Agentpatterns.ai](https://agentpatterns.ai/workflows/worktree-isolation/) correctly notes: "Worktrees are not always perfect isolation — they share the same machine, same network, same ports." Container/VM isolation is stronger for runtime state.
- This is an **isolation/reproducibility question**, not a code quality question

**The claim "cloud agents write better code" is NOT supported by controlled evidence.** What is documented:
- Cloud-hosted frontier models produce better code than small local models (model quality effect, well-documented)
- Cloud background agents (Devin, Cursor Background Agent, Copilot Coding Agent) offer isolation benefits — no disruption to main workspace, contained failures, automatic PR creation ([Upsun developer blog](https://developer.upsun.com/posts/ai/git-worktrees-for-parallel-ai-coding-agents))
- No RCT or controlled study demonstrates that executing the same model in a cloud sandbox produces better code than executing it in a local worktree

[STRUCTURED] — The isolation-vs-quality distinction is reasoned from multiple primary sources. The absence of a controlled cloud-vs-local quality study is itself a confirmed finding.

---

### 2.4 Documented Quality Gaps in AI-Generated Code (2026)

Regardless of execution environment, the consistent quality failure modes for AI-generated PRs are:

| Category | Source | Severity |
|---|---|---|
| Test quality: tests verify implementation, not intent | [dev.to](https://dev.to/toniantunovic/ai-agents-generate-code-that-passes-your-tests-that-is-the-problem-56jb) | High — produces false coverage confidence |
| Missing non-functional requirements (rate limiting, error handling, observability, retry logic) | [Augment Code](https://www.augmentcode.com/guides/the-80-percent-problem-ai-agents-technical-debt) | High — "80% problem" |
| Security: 45% of AI-generated samples introduce OWASP Top 10 vulnerabilities (unchanged across multiple test cycles 2025–early 2026) | [CSA / Veracode 2026](https://labs.cloudsecurityalliance.org/research/csa-research-note-ai-generated-code-vulnerability-surge-2026/) | High |
| Logic errors 75% more common than human code; readability issues 3× | CodeRabbit report, cited in [Autonoma](https://getautonoma.com/blog/ai-coding-agent) | Medium |
| Coherence gaps across files (rename one field, miss three references) | [Autonoma](https://getautonoma.com/blog/ai-coding-agent) | Medium |

**Implication for Relay/Vellum verification design:** The 20% of code that agents systematically omit — error handling, auth guards, observability hooks, edge cases — does not fail CI tests. The verification layer needs explicit non-functional requirement checklists, not just test pass/fail.

[SURE] — Multiple independent sources on quality failure modes; METR is primary; CodeRabbit/Veracode figures are vendor-reported (treat as directional).

---

### 2.5 SWE-bench Scores Are Not Production Quality Signals

For reference only — SWE-bench Verified performance as of April 2026 ([timewell.jp benchmark summary](https://timewell.jp/en/columns/ai-coding-tools-complete-benchmark-2026)):
- Claude Opus 4.5: 80.9%
- Cursor Background Agent: 65.7% (using Sonnet 4.6)
- Devin 2.0: 45.8%

METR's August 2025 update explicitly warns: "automatic scoring used by many benchmarks may overestimate AI agent real-world performance" because benchmarks don't capture test coverage quality, formatting, documentation, or non-functional requirements. [SWE-bench Pro shows ~52% performance drop on enterprise-grade tasks vs standard SWE-bench](https://www.facebook.com/groups/DeepNetGroup/posts/2742070289519169/).

[SURE] — METR's explicit caveat about benchmark overestimation is a primary source finding.

---

## Q3: API Work Variant Taxonomy — Distinct Shapes Requiring Different Checklists

### 3.1 The Core Breaking/Non-Breaking Axis

The foundational classification, stable across [Microsoft](https://learn.microsoft.com/en-us/xandr/digital-platform-api/breaking-changes), [oasdiff](https://www.oasdiff.com/docs/breaking-changes), [Middesk](https://docs.middesk.com/build/api-changes), [Speakeasy](https://www.speakeasy.com/api-design/versioning), and [Red Hat](https://developers.redhat.com/articles/2024/03/25/how-navigate-api-evolution-versioning):

**Breaking (backward-incompatible):**
- Remove or rename a field, endpoint, or parameter
- Change a field's data type
- Make an optional field required
- Add new validation rules that existing payloads would fail
- Change or remove authentication/authorization method
- Decrease rate limits
- Remove enum values (if clients do exhaustive switch matching)
- Change error response format or status code mapping

**Non-breaking (additive/backward-compatible):**
- Add new optional endpoint
- Add new optional request parameter
- Add new optional response field
- Add new enum value (with caveat: strict deserializers may break — test with known consumers)
- Add new webhook event
- Change opaque string formats (IDs, log messages) that clients treat as blobs

[SURE] — This axis is a stable industry standard, codified in multiple governance frameworks and OpenAPI tooling.

---

### 3.2 Defensible Starter Taxonomy — Seven Distinct Shapes

The following taxonomy is derived from: [Shopware API review checklist](https://github.com/shopware/api-working-group/blob/main/templates/api-review-checklist.md), [Treblle governance guide](https://treblle.com/blog/api-governance-best-practices), [duckkit.dev breaking changes checklist](https://duckkit.dev/blog/api-breaking-changes-checklist), [oasdiff rules](https://www.oasdiff.com/docs/breaking-changes), [Medium API change management](https://medium.com/good-api/api-change-management-2fe5bba32e9b), and [dev.to LLM consumer taxonomy](https://dev.to/deepaksatyam/your-api-has-thousands-of-llm-consumers-none-of-them-can-read-your-changelog-5c9e).

---

#### Type 1: New Endpoint (Additive)
**Shape:** New path, method, or resource. No existing clients affected.
**Review requirements:**
- Design review against style guide (naming, HTTP verbs, status codes, error envelope consistency)
- Auth/authz model specified and consistent with existing endpoints
- Rate limiting and pagination defined
- OpenAPI spec present before implementation (contract-first)
- Contract testing added
- No shadowing of existing paths
**Blocks merge if:** Style guide violations, auth not specified, OpenAPI missing
**Key difference from other types:** Lowest risk. Can be gated primarily on design conformance and contract completeness, not backward-compat analysis.

---

#### Type 2: Breaking Change (Modification to Existing Contract)
**Shape:** Field removal, type change, required enforcement, endpoint removal/rename, auth method change.
**Review requirements:**
- Mandatory changelog entry with explicit "BREAKING" flag
- Migration guide for existing consumers
- Sunset/deprecation period enforced (Microsoft Graph: ≥24 months; shorter acceptable for internal-only APIs)
- OpenAPI diff check must pass (oasdiff or equivalent) — blocks merge if breaking change not acknowledged
- Version bump required (new major version or explicit deprecation header per [RFC 8594 Sunset header](https://datatracker.ietf.org/doc/html/rfc8594))
- Consumer notification before deploy
**Blocks merge if:** Breaking change detected without changelog + migration guide; version not bumped
**Key difference:** Highest process overhead. This type *must* route through human-in-the-loop regardless of who wrote the code.

---

#### Type 3: Bugfix (Behavioral Correction, Non-Breaking)
**Shape:** Fix incorrect behavior that violates the documented contract, while staying contract-compatible.
**Review requirements:**
- Regression test covering the bug scenario added
- Confirm fix doesn't change behavior for valid (non-buggy) inputs
- Verify that the "broken" behavior wasn't load-bearing for any consumer (documented workarounds may have been built on it)
- Security-class bugs: treat as Type 6 (Auth/Security Change) if the bug involves auth or input validation
**Blocks merge if:** No regression test; behavioral change wider than documented bug
**Key difference from breaking change:** Lower process overhead, but requires proof via test that the fix is scoped. "The old behavior was a bug" is often disputed; human review is essential.

---

#### Type 4: Deprecation (Lifecycle Transition, Not Yet Removal)
**Shape:** Marking an endpoint, field, or parameter as `deprecated: true` in OpenAPI; no behavioral change yet.
**Review requirements:**
- Sunset date set and announced (minimum notice window per your policy)
- `Deprecation` and `Sunset` HTTP response headers added per RFC 8594
- Usage analytics reviewed (is anyone calling it?)
- Migration path or replacement documented
- Changelog entry
**Blocks merge if:** Deprecated without sunset date ([oasdiff rule: `api-deprecated-sunset-missing`](https://www.oasdiff.com/docs/breaking-changes)); no migration path documented
**Key difference from breaking change:** Does not break consumers now. Lower urgency, but requires process discipline to prevent deprecations becoming permanent dead weight.

---

#### Type 5: Auth/Authorization Change
**Shape:** Changes to authentication method (API key → OAuth 2.0, token format change, scope addition/removal), authorization model change, security protocol modification.
**Review requirements:**
- Explicitly classified as breaking (SmartRecruiters: ["Authentication & Authorization Changes are considered breaking changes"](https://developers.smartrecruiters.com/docs/breaking-changes))
- Security review mandatory (OWASP API Security Top 10 — Broken Object Level Authorization, Broken Function Level Authorization are the top API vulnerability classes)
- Token migration / parallel support period defined
- Rate limit and abuse-prevention impacts assessed
- Threat model updated
**Blocks merge if:** No security review; breaking auth change without deprecation period
**Key difference:** Highest security surface. Should trigger Relay/Vellum's most stringent audit chain regardless of source. Never ship an auth change from an autonomous agent without explicit human sign-off on the threat model.

---

#### Type 6: New Feature on Existing Endpoint (Additive, Non-Breaking)
**Shape:** New optional request fields, new optional response fields, new optional query parameters on existing endpoint.
**Review requirements:**
- Postel's Law check: are clients required to handle the new field? If yes, reclassify as breaking.
- Strict-deserializer warning: known consumers using `FAIL_ON_UNKNOWN_PROPERTIES` (Jackson default) may break on new response fields — [duckkit.dev](https://duckkit.dev/blog/api-breaking-changes-checklist)
- Documentation updated
- Backward compatibility proof: existing request payloads must still work unchanged
**Blocks merge if:** New field is response-only but existing consumers use strict parsers without being tested; field made required
**Key difference from new endpoint:** Touches existing contract surface; slightly higher backward-compat risk than pure addition.

---

#### Type 7: Performance/Operational Change (Non-Behavioral)
**Shape:** Rate limit adjustments, timeout changes, caching behavior, pagination changes, payload size limit changes.
**Review requirements:**
- Consumer impact analysis (rate limit decrease = breaking; rate limit increase = non-breaking)
- SLA impact assessed
- Runbook/operational docs updated
- Staged rollout for limit decreases
**Blocks merge if:** Rate limit decrease or timeout reduction without consumer notification (treat as breaking)
**Key difference:** Behavioral contract unchanged; operational contract affected. Often overlooked by AI agents generating endpoint code — this class of change requires explicit human judgment about consumer impact.

---

#### Extended: LLM/AI Consumer Considerations (Emerging)
[dev.to post (June 2026)](https://dev.to/deepaksatyam/your-api-has-thousands-of-llm-consumers-none-of-them-can-read-your-changelog-5c9e) identifies three new failure modes for frozen (AI-agent) consumers that are **not breaking for human-written consumers**:
- **Lexical breaks:** Renaming a field from `user_id` to `userId` — old taxonomy says non-breaking (just a string change); AI agents trained on the old field name silently fail
- **Semantic drift:** Field meaning changes without type change (e.g., `status` field acquires new enum values that agents don't handle)
- **Prompt-injection via changed error messages:** Error text that agents parse as instructions

[NEEDS_RESEARCH] — This is a newly documented problem (June 2026) with no established checklist conventions yet. Amplified's AI-heavy consumer base makes this particularly relevant; the Relay/Vellum audit layer is well-positioned to capture changelog provenance for exactly this class of change.

---

### 3.3 Review Requirement Differentiation by Type

| Change Type | OpenAPI Diff Required | Human Sign-off Required | Consumer Notification | Regression Test Required | Security Review |
|---|---|---|---|---|---|
| New Endpoint | Advisory | Style review | No | Contract test | If auth surface |
| Breaking Change | **BLOCKING** | **Yes** | **Yes** | Yes | Yes |
| Bugfix | Advisory | Scope verification | No | **Yes** | If security bug |
| Deprecation | Advisory | Yes (sunset date) | **Yes** | No | No |
| Auth Change | **BLOCKING** | **Yes** | **Yes** | Yes | **Yes — mandatory** |
| New Feature (existing) | Advisory | Strict-parser check | No | Yes | If auth surface |
| Operational Change | Advisory | Consumer impact | If limit decrease | No | No |

[STRUCTURED] — Taxonomy and differentiation table is synthesized from multiple governance sources. The seven-type split is defensible and covers the practical surface of API work; some organizations use more granular taxonomies (e.g., splitting "endpoint removal" from "field removal").

---

## Cross-Cutting Notes for Amplified's Relay/Vellum Design

1. **Gate design implication from Q1+Q2:** The 20–30 min "polishing to merge-ready" gap METR documented means Relay/Vellum should explicitly verify non-functional requirements (error handling, auth guards, observability) as a checklist step *independent* of CI test pass/fail. Tests passing is insufficient.

2. **AI PR acceptance rate (32.7%) means queue pressure management is required.** With high agent PR volume, a merge queue configured with parallel CI and proper `merge_group` trigger is not optional — it is structural. Without it, a high-rejection-rate AI-PR stream creates backlog that compounds against the 4.6× wait time.

3. **Auth changes (Type 5) are the category most dangerous for autonomous agent authority.** The existing architecture — agents push PRs, no unilateral merge authority — is correct. Auth/security changes should require explicit human review *above and beyond* the normal Relay/Vellum audit trail.

4. **"Cloud writes better code" is not a defensible claim.** Isolation benefits of cloud execution are real (no local state contamination, auditable environment). Code quality depends on model capability and prompting, not execution venue. Worktree isolation achieves the containment goal at lower latency.

5. **LLM-consumer semantic breaks (Q3 extended finding)** are an emerging gap: changes non-breaking for human consumers can silently break AI agents that consume the API. Relay/Vellum provenance tracking is particularly well-suited to capture these since it can link API contract changes to downstream agent behavior.

---

## Source Index

| Finding | Primary Source | Confidence |
|---|---|---|
| CI p50/p95 targets | [Harness CI metrics](https://www.harness.io/blog/top-continuous-integration-metrics-every-platform-engineering-leader-should-track), [DX metrics](https://lucaberton.com/blog/developer-experience-metrics-devex/), [DORA 2024](https://codeligence.com/research/engineering-metrics/) | [SURE] |
| AI PR 4.6× wait, 32.7% acceptance | [LinearB 2026 / ByteIota analysis](https://byteiota.com/software-engineering-benchmarks-2026-ai-code-review-gap/) | [SURE] |
| Task-type dominance in AI PR acceptance | [Pinna et al. arXiv:2602.08915](https://arxiv.org/abs/2602.08915) | [SURE] |
| GitHub merge queue mechanics | [GitHub Docs](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue) | [SURE] |
| Graphite parallel CI outcomes | [Graphite blog](https://graphite.com/blog/the-first-stack-aware-merge-queue) | [STRUCTURED] (vendor-reported) |
| METR 19% slowdown RCT | [METR July 2025](https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/) | [SURE] |
| METR Feb 2026 follow-up withdrawal | [METR Feb 2026](https://metr.org/blog/2026-02-24-uplift-update/) | [SURE] |
| METR "none mergeable" finding | [METR Aug 2025](https://metr.org/blog/2025-08-12-research-update-towards-reconciling-slowdown-with-time-horizons/) | [SURE] |
| AI code quality gaps (80% problem, test quality, security) | [Augment Code](https://www.augmentcode.com/guides/the-80-percent-problem-ai-agents-technical-debt), [CSA/Veracode 2026](https://labs.cloudsecurityalliance.org/research/csa-research-note-ai-generated-code-vulnerability-surge-2026/), [Autonoma](https://getautonoma.com/blog/ai-coding-agent) | [SURE] — multiple corroborating sources |
| Cloud vs local quality: model quality effect | [fp8.co 2026](https://fp8.co/articles/Local-AI-Coding-Agents-Small-Models-vs-Cloud-Comparison), [kunalganglani.com](https://www.kunalganglani.com/blog/local-llm-vs-claude-coding-benchmark) | [STRUCTURED] — benchmarks not RCTs |
| Worktree isolation mechanics | [agentpatterns.ai](https://agentpatterns.ai/workflows/worktree-isolation/), [Upsun dev](https://developer.upsun.com/posts/ai/git-worktrees-for-parallel-ai-coding-agents) | [SURE] |
| API change taxonomy (breaking/non-breaking) | [oasdiff](https://www.oasdiff.com/docs/breaking-changes), [Middesk](https://docs.middesk.com/build/api-changes), [Microsoft](https://learn.microsoft.com/en-us/xandr/digital-platform-api/breaking-changes) | [SURE] |
| Auth change = breaking | [SmartRecruiters](https://developers.smartrecruiters.com/docs/breaking-changes) | [SURE] |
| API governance checklist practice | [Treblle 2026](https://treblle.com/blog/api-governance-best-practices), [Shopware checklist](https://github.com/shopware/api-working-group/blob/main/templates/api-review-checklist.md) | [SURE] |
| LLM consumer semantic breaks (new) | [dev.to June 2026](https://dev.to/deepaksatyam/your-api-has-thousands-of-llm-consumers-none-of-them-can-read-your-changelog-5c9e) | [NEEDS_RESEARCH] — emerging, no established practice |
| RFC 8594 Sunset header | [IETF RFC 8594](https://datatracker.ietf.org/doc/html/rfc8594) | [SURE] |
