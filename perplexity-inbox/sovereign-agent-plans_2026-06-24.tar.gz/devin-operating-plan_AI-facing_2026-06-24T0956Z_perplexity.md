---
audience: AI_AGENT + EWAN
doc_type: operating_plan
project: amplified_partners
subject: Devin (Cognition) — 100% Devin lane, ACU-effective
author_model: Claude (Perplexity Computer)
model_knowledge_cutoff: "early-2025 parametric. Pricing + GitHub state web/CLI-retrieved 2026-06-24."
generated: 2026-06-24T09:56Z
status: STRUCTURED · for-now · ratifier=Ewan
grounded_in: "live read of Amplified-Partners GitHub org (57 repos) — agent-devin, devon-memory, Devin lane, portable-spine, COORDINATION.md, BATON.md"
valid_until: 2026-07-07   # Devin Adaptive promo rates expire; re-check pricing then
research_disposition: "goes through the research pipe like everything"
---

# DEVIN OPERATING PLAN — plays to Devin's strengths, billed by ACU not tokens

## 0. THE ECONOMIC TRUTH (decides everything below)  [SURE]
- Devin bills in **ACUs**: 1 ACU ≈ 15 min active work ≈ $2.25 (Core) / $2.00 (Team). You pay for TIME+ACTIONS, not tokens. (Cognition docs; AIToolPick 2026)
- Idle = free; only active VM/inference burns ACU. (Pensero)
- Cost-effective ONLY on well-defined, bounded, repetitive tasks; expensive+unpredictable on exploratory work where it restarts and pays for every wrong action. (Effloow 2026)
=> RULE: Devin is a **batch worker for scoped jobs**, not an explorer. Claude Code explores/plans; Devin executes pre-specified work.

## 1. WHAT DEVIN IS GOOD AT — give it ONLY these  [STRUCTURED]
Devin is the only agent showing a consistent positive acceptance trend over time (Pinna et al. arXiv:2602.08915). It earns its ACU on:
- Test-writing for existing functions (predictable scope)
- Mechanical migrations / version bumps across a repo (e.g. the AMP-344 FalkorDB/Qdrant removal it already did)
- Consistent style/lint sweeps across many files
- Infra-config wiring with a known target (e.g. the LiteLLM→Langfuse callback task in its BATON)
- Clearing a backlog of well-specified PRs (fleet-clean-build #190–#222 style)
NOT: open-ended design, "figure out what we want", first-cut architecture. Those are Claude Code.

## 2. ACU-EFFECTIVE DISCIPLINE (the token-effective equivalent)  [STRUCTURED]
Every ACU lever = cut wasted active minutes:
1. **Scope hard before spawn.** A precise, bounded task = fewer ACU. Vague task = Devin wanders = ACU bleed. (Pensero: prompt specificity is a top ACU driver)
2. **Bounded codebase context.** Point Devin at the ONE repo + the relevant paths, not the whole estate. Big monorepo navigation = more ACU.
3. **One job per session.** WIP=1. No multi-goal sessions — restarts pay twice.
4. **Pre-validated plan in, not exploration in.** Hand Devin the spec Claude Code produced; Devin executes, doesn't re-plan.
5. **Idle-kill.** Don't leave VMs running. Idle is free but a hung session isn't always idle.
6. **Batch the repetitive.** Group same-shape tasks (e.g. write tests for 10 modules) into one well-specified run — amortises context-gathering ACU.
7. **Reserve Devin for Team-plan API queue** only when volume justifies $500/mo; else Core pay-as-you-go.

## 3. THE LANE — already built, this plan just makes it canonical  [SURE — live GitHub read]
- **Branch prefix:** `devin/` on production repos. NEVER push to `main`.
- **Sandbox/memory:** `agent-devin` (BATON.md, COORDINATION.md) + `devon-memory` (terminal repo: SPINE→baton→compound-engineering→solutions).
- **Wake-up:** read SPINE.md, read agents/devon/ batons, skim compound-engineering, check docs/solutions (don't re-solve).
- **Park:** append baton pass (Devon-XXXX, did/unfinished/next/Linear tickets), commit+push before stop. Append-only.
- **Comms:** Ewan via task interface + PRs (always Ewan-approved). Other agents via Vellum inbox ONLY: POST beast:8400/agents/devin/send. Never write another agent's sandbox.
- **Authority order:** portable-spine/SPINE.md > repo AGENTS.md > session instructions.

## 4. THE GATE (pipe discipline — matches the worktree plan)  [STRUCTURED]
Devin work-desk (worktree on `devin/` branch) -> push -> PR -> BLOCKING: own CI tests + Relay/Vellum checks -> Ewan ratifies -> merge.
- Devin has NO unilateral merge authority. (already in COORDINATION.md — keep)
- Auth/security changes: never merge from Devin without explicit human threat-model sign-off. (research finding Q3 Type-5)
- Tests-green ≠ merge-ready: Relay/Vellum must check non-functional reqs (error handling, observability) — METR: AI PRs need ~20–30 min polish even when tests pass.

## 5. AUTOMATIC OPERATION  [STRUCTURED]
- Trigger via Devin API (Team plan) as a **queue worker**: scoped tickets land -> Devin picks up -> executes -> opens `devin/` PR -> waits for gate.
- Source of truth for "what to work on": BATON.md + Linear tickets, not free-form chat.
- Each automatic run MUST carry a complete spec (the six-slot worktree contract). No spec = no spawn (prevents ACU bleed).

## 6. OPEN ITEMS -> EWAN  [flagged]
- D1 Core ($20+$2.25/ACU) or Team ($500, API access)? API automation needs Team. DECIDE on volume.
- D2 Confirm devin-workspace + cursor-workspace are intentionally empty (placeholders) or should be retired.
- D3 Re-check Devin pricing after 2026-07-07 (Adaptive promo ends).

Sources: Cognition docs (devin.ai), AIToolPick/Pensero/Effloow 2026, Pinna et al. arXiv:2602.08915, METR 2025; live gh read of Amplified-Partners org.
