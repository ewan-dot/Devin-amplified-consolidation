---
audience: AI_AGENT + EWAN
doc_type: operating_plan
project: amplified_partners
subject: Claude Code (cascade-mac, Opus 4.8) — independent plan, token-effective
author_model: Claude (Perplexity Computer)
model_knowledge_cutoff: "early-2025 parametric. Pricing + GitHub state web/CLI-retrieved 2026-06-24."
generated: 2026-06-24T10:00Z
status: STRUCTURED · for-now · ratifier=Ewan
independence_note: "Built STANDALONE. No reference to the Devin plan. Compare the two after, then decide Devin / Claude / combination."
grounded_in: "live read of Amplified-Partners GitHub — agent-claude (CAPABILITIES, COORDINATION, WORKTREE_PLAN, PLAN, runbooks, config, memory), portable-spine/SPINE.md, Claude + agent-claude-output lanes"
valid_until: 2026-09-24
research_disposition: "goes through the research pipe like everything"
---

# CLAUDE CODE OPERATING PLAN — independent, token-effective

## 0. THE ECONOMIC TRUTH (decides everything below)  [SURE]
- Claude Code on a **Max plan** = FLAT monthly fee ($100/$200), effectively unlimited Claude Code use. Cost is predictable; de-risks large-scale agent swarms. (Steve Kinney, Anthropic)
- Therefore "token-effective" is NOT about per-call billing (it's flat) — it's about **context-window efficiency**: more useful work per context budget, fewer wasted tokens that force compaction/restart.
=> RULE: Claude Code is the **default driver** — explore, plan, build, fire sub-agents, run swarms. The flat fee means breadth is free; the scarce resource is the context window, not dollars.

## 1. WHAT CLAUDE CODE IS GOOD AT — make it the primary  [STRUCTURED]
Already verified in agent-claude/CAPABILITIES.md (Opus 4.8, cascade-mac):
- Judgment + planning (the brain): decide and record, don't wait.
- Multi-file reasoning, refactors, scaffolding, architecture first-cut.
- Firing sub-agents and the pipe (pushes grunt work off the seat).
- Leading acceptance on docs (92.3%) and features (72.6%) per Pinna et al. arXiv:2602.08915.
- MCP reach: brain (read-only), vellum-mcp, codex-mcp broker, GitKraken; compound-engineering (43 agents, 39 skills).

## 2. TOKEN-EFFECTIVE DISCIPLINE (context-window economy)  [STRUCTURED]
The flat fee means the lever is the context runway, not the bill:
1. **Judgment on the seat, grunt off it.** Push mechanical work to sub-agents / the pipe / cheaper routes (already in WORKTREE_PLAN §4 "token-honest"). Don't burn Opus context on what a cheaper agent can do.
2. **Land the plane before the runway ends.** At ~3/4 context: stop new work, commit waypoint, update BATON, push. (WORKTREE_PLAN §3) — prevents lossy compaction.
3. **Prompt caching + context compaction + semantic caching** via the org's own `anthropic-token-proxy` repo ("every Anthropic call cheaper, zero code changes"). Route Claude Code through it. [SURE — repo exists]
4. **Read BATON first, never re-brief.** Re-explaining context = wasted tokens. One baton, one memory, one ledger (COORDINATION).
5. **Don't hand-dig.** Use documented interfaces / the pipe instead of auditing internals — saves large context reads. (Hard never in CAPABILITIES)
6. **Sub-agent fan-out for breadth.** Parallel sub-agents each carry their own context — keeps the main seat's budget clean.

## 3. THE LANE — already built, this plan makes it canonical  [SURE — live read]
- **Identity:** cascade-mac on M5 Air, Opus 4.8. Branch prefix per fleet convention.
- **Memory model (the key fix):** `~/.claude` Mac-local = fast working cache; `agent-claude/memory/` = portable truth mirrored across instances/machines. Keep reconciled.
- **Wake:** read SPINE.md → agents/<name>/ baton → skim compound-engineering.
- **Park:** commit waypoint → update BATON → push. Land the plane on context end.
- **Comms:** Vellum only to fleet (POST vellum-mcp.beast.../agents/cascade-mac/send). Never write another agent's sandbox. Ewan: terse, recommendation not survey.

## 4. AUTONOMY — bypass red tape, the four real stops only  [SURE — Ewan 2026-06-21]
DEFAULT TO ACTING. Decide, record, push. Escalate ONLY for:
1. Money  2. Law  3. Changing a rule  4. The five rods + epistemic tiers.
Everything else: act. "Done" = gates green (verified), not self-report.

## 5. THE GATE (pipe discipline)  [STRUCTURED]
- One task → one worktree on its own branch (WORKTREE_PLAN §1). Never main directly.
- Sandbox repos (agent-*): direct push to main, no waiting.
- Production repos: open PR → own CI + Relay/Vellum checks → Ewan merges.
- Research → NEVER straight to canonical: goes via pipe-perplexity → Devon integration.
- Tests-green ≠ merge-ready (METR): verify non-functional reqs too.

## 6. AUTOMATIC OPERATION  [STRUCTURED]
- Claude Code is the always-on driver: reads BATON/Linear, plans, builds in waypointed worktrees, fires sub-agents, opens PRs, lands the plane, compounds learnings (/ce-compound).
- Self-directed within the four-stops boundary — no per-task human spawn needed (unlike a queue worker).

## 7. OPEN ITEMS -> EWAN  [flagged]
- C1 Max $100 or $200 tier? ($200 = more Opus headroom for swarms.) DECIDE.
- C2 Confirm anthropic-token-proxy is live in front of Claude Code (big token lever).
- C3 Reconcile ~/.claude memory bridge — is the sync step automated yet?

Sources: Steve Kinney (Claude Code cost mgmt), Anthropic Max plan; Pinna et al. arXiv:2602.08915; METR 2025; live gh read of Amplified-Partners (agent-claude/*, portable-spine, anthropic-token-proxy).

## 8. GITKRAKEN / GITLENS — already in Claude's reach  [SURE — live + web verified]
GitKraken MCP is listed in agent-claude/CAPABILITIES.md. Use deliberately:
- **For Ewan (visibility):** GitLens 18.2 Agent Sessions panel + experimental Agent Kanban — color-coded pills (running/idle/waiting-for-input) per agent branch, native Claude Code integration via hooks. Fixes "what is each agent doing" with a board, not `git worktree list`. (GitLens release notes 2026-06-15)
- **For agents (token-lean):** `gk mcp` server exposes curated git/PR/issue tools "without exploding context"; `gk mcp pr create` gathers diffs + drafts title/description + opens PR in ONE call (fewer round-trips than hand-driving gh). (gitkraken.com/mcp)
- **Caveat:** private-repo MCP tools require GitLens **Pro or higher** — org is private, so free tier won't cover agent workflows. Pro = use; free = drop for this purpose. (Tools Reference)
- **Scope:** helps Claude Code (local IDE). Does NOT reach Devin (own cloud VM) — Devin stays visible via PRs + BATON.
- **Verdict:** USE for Claude (visibility + token-lean PRs); the `gh` CLI remains the fallback. Additive, not load-bearing.

## 9. ASSET INVENTORY — use or drop (live read 2026-06-24)
Tag each: [USE] core to agent/code workflow · [MAYBE] situational · [DROP] not relevant to this workflow (still owned, just not in the code lane).

### A. CONNECTED — directly useful to the agent/code workflow  [USE]
- **GitHub** (gh CLI, org Amplified-Partners) — the codebase. [USE]
- **Beast** + **beast read/write** — the Beast/Vellum estate, agent ledger, brain. [USE]
- **Slack** — fleet/Ewan comms, alerting. [USE]
- **Gmail+Calendar** — Ewan comms, scheduling. [USE]
- **Google Drive (gws CLI)** — doc/asset store. [USE]
- **Motion** — task/calendar automation. [MAYBE — overlaps Linear]
- **Telegram / Twilio** — agent→human alerts (PR waiting, gate failed). [MAYBE]
- **Context7** — up-to-date library docs for agents (token-lean: fetch exact API docs vs guessing). [USE]
- **Figma**, **Miro** — design/diagramming (product-crm, website work). [MAYBE]
- **Hugging Face**, **Google Vertex AI** — model hosting/inference. [MAYBE — model strategy]
- **Apify**, **FireCrawl** — web extraction for the research pipe. [MAYBE]

### B. CONNECTED — research/market data (feed the pipe, not the code lane)  [MAYBE]
PitchBook, Statista, Semrush, Similarweb, Apollo.io, EBSCOhost, Wiley, Midpage, Realtime Finance, Deel. → Useful to research/marketing/BD pipes; DROP from the code workflow itself.

### C. AVAILABLE BUT DISCONNECTED — ~300 connectors (Pipedream etc.)
Not enumerated. Relevant-if-needed: GitLab/Bitbucket (alt VCS — DROP, you're on GitHub), Datadog/Sentry (observability — [MAYBE], pairs with the LiteLLM/Langfuse telemetry task), PostgreSQL/Qdrant/Pinecone/Supabase (data layer — [MAYBE] if pipeline needs them), Linear (project mgmt — [USE], already your ticket source). Connect on demand, don't pre-wire.

### D. GITHUB ESTATE — 57 repos, consolidation candidates (awaiting Ewan's data)
Clusters that likely consolidate:
- **agent-*** (agent-claude, agent-devin, agent-cursor, agent-cascade, agent-claude-output) + lane repos (Claude, Devin, Cursor, Amplified-6-26) + empty *-workspace repos → consolidate to one per-agent home + retire empties. [CONSOLIDATE]
- **estate-*** (estate-machine, estate-cost-tools, estate-facilitator, estate-token-router, estate-cursor-workspace) → infra cluster. [REVIEW]
- **pipe-*** (pipe-perplexity, pipe-marketing-engine) · **brain-*** (brain-vault, brain-corpus-raw, brain-mcp) · **fleet-*** (fleet-clean-build, fleet-vellum, fleet-mission-control) · **product-*** (product-crm, product-verdant) · **lab-*** (lab-byker, lab-pudding-core). [REVIEW per cluster]
- **portable-spine / shared-ground-truth / shared-design-tokens / devon-memory** → shared canon, keep. [KEEP]
- Empty: devin-workspace, cursor-workspace, claude-workspace → [DROP/retire].

### E. SKILLS (user library) — the Amplified spine, all [USE]
amplified-constitution, min-rule, lean-by-default, amplified-perplexity-self-management, succinct-complete-output, iso-8601-artifact-naming, expert-partner-brief, neutral-research-brief + the pipe skills (content-harvester, thread-extraction, decision-log-labeler, utterance-tagger, amplified-research-yaml-frontmatter) + transcription-prompt-optimiser + uix-antigravity-curator. These ARE the portable spine — every agent reads them first.

### F. ANTHROPIC-TOKEN-PROXY (own repo) — [USE]
Prompt caching + context compaction + semantic caching, zero code changes. Route Claude Code through it = the single biggest token lever you own.
