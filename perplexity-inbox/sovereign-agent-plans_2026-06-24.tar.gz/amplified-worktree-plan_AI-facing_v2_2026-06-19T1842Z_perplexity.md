---
audience: AI_AGENT_ONLY
doc_type: plan_as_it_stands           # outcome of session; to be tested against research pipe
project: amplified_partners
author_model: Claude (Perplexity Computer)
model_knowledge_cutoff: "early 2025 parametric. ALL time-sensitive claims below were web-retrieved 2026-06-19 this session, NOT parametric memory."
generated: 2026-06-19T18:42Z
status: STRUCTURED · for-now · ratifier=Ewan(human, proxy-loggable)
research_disposition: "EVERYTHING goes through the research pipe — standing policy. This doc is the plan as it stands, not law. We trust ourselves but we cannot. Re-verify, then re-ingest."
valid_until: 2026-09-19
terminology_marker: "(Ewan_term) ^ proper_term — brackets first (human), proper term binds agent, ^ = metaphor"
confidence_legend: {SURE: "documented, stable (git/CI mechanics)", STRUCTURED: "reasoned + corroborated, not empirically validated by us", NEEDS_RESEARCH: "vendor-claimed or intuited; verify before reliance/spend"}
session_verification: "5-min pass run 2026-06-19. Outcome: design HELD. 3 sharpenings added (see VERIFIED block). No refutations."
---

# AMPLIFIED WORKTREE PLAN — AS IT STANDS (AI-FACING)

## 0. EPISTEMIC PREAMBLE
Author cutoff early-2025. Do NOT treat time-sensitive lines as parametric fact.
Min-rule applies. Everything tagged NEEDS_RESEARCH = halt-and-verify before reliance/spend.
Standing policy: ALL of this routes to the research pipe regardless of confidence.

## 1. SIX MANDATORY SLOTS  [SURE structure / STRUCTURED contents]
(work-tree)^worktree carries all six. Slots fixed, contents selectable.
- START [SURE]: print `git remote -v`+`pwd`, HALT for ratifier go.
- WAYPOINTS [STRUCTURED]: blank-but-mandatory, each needs 1-line rationale (tick alone = loophole).
  VERIFIED: classic checklist rule "ensure each question considered for every piece of code" (CMU).
- GOOD [STRUCTURED]: positive exemplar. VERIFIED: AGENTS.md best practice = short rule + ONE code example.
- BAD [STRUCTURED]: negative exemplar / what NOT to ship. (high-value; uncommon; keep.)
- HOOKS [SURE]: tests/lint/CI, machine-only.
- FINISH [SURE]: = a NAMED verification command that passes, not a vibe.
  VERIFIED: "Completion Evidence" — every task carries a verification cmd e.g. curl ... | jq .status==201 (Walking Labs L07).

## 2. WIP=1  [SURE — newly added from verify]
One agent finishes one task (passing) before starting next. "Overreach/under-finish" are quantifiable.
Maps to Ewan's "always start to finish, one outcome".

## 3. SELECTABLE VARIANTS  [STRUCTURED]
api-new-endpoint | api-breaking-change | api-bugfix — all keep 6 slots.
GOAL-LOCK: ship ONE first; split only when one variant handles a real job badly.
[NEEDS_RESEARCH] exact variant taxonomy vs real codebase + consensus.

## 4. TWO-REVIEWER (GitHub gate)^pull-request gate  [STRUCTURED — VERIFIED as the documented norm]
merge_iff: helper_approves AND neutral_passes AND Ewan_ratifies.
- (helper)^Amplified reviewer — OURS — STRUCTURED judgment: serves goal? obeys rods? improves not corrupts.
- (cold-check)^neutral tester — THIRD-PARTY — MEASURED fact: runs tests, pass/fail, unflatterable.
VERIFIED: "AI made burden of proof explicit — automated tests prove it works, review judges intent" (Osmani).
VERIFIED: AI reviewers CANNOT replace human sign-off -> Ewan ratify step is REQUIRED not optional.
VERIFIED (load-bearing reason): AI PRs ~32.7% acceptance vs 84.4% human -> automated gates "non-negotiable" (CodeAnt).

## 5. SPEED — "gates slow code a shitload" — RESOLVED BY LAYERING  [STRUCTURED]
Problem (VERIFIED): AI PRs wait 4.6x longer for pickup (CodeAnt). Slow gate = dead velocity.
RULE: only FAST checks block merge. AI review runs in PARALLEL, advisory, NON-blocking.
- BLOCKING (must pass, fast, sec-min): your CI test suite + security scan (Snyk). THIS is the true neutral.  [SURE this is the neutral layer]
- ADVISORY (parallel, never blocks): AI reviewer (catches 70-80% low-hanging fruit but has opinions+latency -> behaves like a 2nd helper, not the neutral).  [STRUCTURED]

## 6. THIRD-PARTY AUDITOR OPTIONS  [ALL NEEDS_RESEARCH before spend]
| tool | role | neutral? | speed | note |
|------|------|----------|-------|------|
| Own CI test suite (GitHub Actions) | tests | TRUE neutral | as fast as tests | the real cold-check; free-ish; you own it [SURE] |
| Snyk | security/deps scan | TRUE neutral (narrow) | fast | opinion-free by nature [SURE scope] |
| CodeRabbit | AI PR review | helper-like | PR-time, tunable | NEEDS_RESEARCH |
| Qodo (ex-Codium) | AI review + test-gen | helper-like | CI-integrated | NEEDS_RESEARCH |
| CodeAnt AI | AI review+security, 4 platforms | helper-like | markets as fast gate | NEEDS_RESEARCH |
| Graphite | merge queue (velocity) | n/a — not an auditor | speeds merging | SURE re role |
RECOMMENDATION (STRUCTURED): neutral layer = own CI tests + Snyk (fast, opinion-free, blocking).
Add ONE AI reviewer as parallel advisory only. Pick after research on cost/speed/false-positive rate.

## 7. MODEL-AGNOSTIC + CLOUD  [STRUCTURED]
Same contract local OR cloud. Cloud advantage = ISOLATION/parallelism (MEASURED, vendor docs).
[NEEDS_RESEARCH] cloud CODING QUALITY unproven — METR 2025 RCT 19% slower; 2026 follow-up scrapped unreliable.
Do NOT assert "cloud writes better code".

## 8. OPEN ITEMS — EWAN CLARIFICATION -> research pipe
- C1 'T&O' = top-and-one-level? (assumed yes) CONFIRM
- C2 first variant/work-shape? (API/ingest/finance-report) DECIDE
- C3 which neutral CI + which (if any) AI reviewer? DECIDE after C6 research
- C4 local now or cloud now? (design identical) DECIDE
- C5 who ratifies the ratifier long-term? UNRESOLVED (constitution open q)
- C6 research auditor tools: cost, p50/p95 latency, false-positive rate, self-host/sovereignty fit

## 9. RESEARCH HANDOFF
All [NEEDS_RESEARCH] + all C-items -> research pipe. This doc = feedstock, not law. Re-ingest after verify.
